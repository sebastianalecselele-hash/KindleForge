#!/bin/sh

set -e

rm -rf /mnt/us/.kinamp.conf
rm -rf /mnt/us/.kinamp_playlist.m3u
rm -rf /mnt/us/KinAMP
rm -f /mnt/us/documents/kinamp.sh

exit 0