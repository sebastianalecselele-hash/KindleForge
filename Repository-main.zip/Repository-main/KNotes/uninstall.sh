#!/bin/sh

set -e

rm -rf /mnt/us/documents/KNotes/
rm -rf /var/local/mesquite/KNotes/
rm -f /mnt/us/documents/KNotes.sh

exit 0