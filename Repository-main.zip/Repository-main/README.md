# Repository

## The Official KindleForge Package Repository

*Hosted on https://kf.penguins184.xyz/*

Current packages (20):

- GambatteK2 
- Gargoyle
- GNOME Games Suite
- JarLauncher
- KAnki
- KinAMP
- KindleCraft
- KindleFetch
- KNotes
- KOReader
- KPM
- Kreate
- KShips
- kTerm
- KUAL (PEKI)
- KWordle
- SOX
- Textadept
- Toggle ADs
- UpdateBlock Status
- LARKPlayer

Credits:

- Dammit Jeff (KOReader, Gambatte-K2, ToggleAds, UpdateBlock Icons)
