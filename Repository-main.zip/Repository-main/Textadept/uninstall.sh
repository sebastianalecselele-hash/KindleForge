#!/bin/sh

set -e

rm -rf /mnt/us/textadept11
rm -rf /mnt/us/extensions/textadept

exit 0