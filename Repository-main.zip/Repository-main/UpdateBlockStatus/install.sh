#!/bin/sh

set -e

curl -fSL --progress-bar -o /mnt/us/documents/updateblock.sh https://kf.penguins184.xyz/UpdateBlockStatus/assets/updateblock.sh

exit 0