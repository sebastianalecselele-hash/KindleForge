#!/bin/sh

set -e

rm -rf /mnt/us/documents/kwordle/
rm -rf /var/local/mesquite/kwordle/
rm -f /mnt/us/documents/kwordle.sh

exit 0