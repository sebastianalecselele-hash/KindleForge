#!/bin/sh

set -e

rm -rf /mnt/us/extensions/koreader
rm -rf /mnt/us/koreader
rm -f /mnt/us/documents/koreader.sh # KindleForge Default Scriptlet

exit 0