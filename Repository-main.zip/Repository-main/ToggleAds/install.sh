#!/bin/sh

set -e

curl -fSL --progress-bar -o /mnt/us/documents/toggle-ads.sh https://kf.penguins184.xyz/ToggleAds/assets/toggle-ads.sh

exit 0