#!/bin/sh

set -e

rm -f /mnt/us/documents/toggle-ads.sh 

exit 0