#!/bin/sh

set -e

rm -rf /mnt/us/documents/kanki/
rm -rf /var/local/mesquite/kanki/
rm -f /mnt/us/documents/kanki.sh

exit 0