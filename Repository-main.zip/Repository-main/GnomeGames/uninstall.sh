#!/bin/sh

set -e

rm -rf /mnt/us/extensions/gnomegames
rm -f /mnt/us/documents/shortcut_gnomechess.sh # If Copied
rm -f /mnt/us/documents/shortcut_gnomine.sh

exit 0