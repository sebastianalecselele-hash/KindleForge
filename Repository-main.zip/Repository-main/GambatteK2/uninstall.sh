set -e

rm -rf /mnt/us/extensions/gambatte-k2
rm -f /mnt/us/documents/shortcut_gambatte-k2.sh # If Copied (Default KUAL)
rm -f /mnt/us/documents/gambatte-k2.sh # Default KindleForge

exit 0