#!/bin/sh

set -e

rm -rf /mnt/us/extensions/sox
rm -rf /mnt/us/music

exit 0