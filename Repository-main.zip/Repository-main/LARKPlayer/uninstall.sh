#!/bin/sh

set -e

rm -f /mnt/us/documents/lark.sh
rm -rf /mnt/us/extensions/lark
rm -rf /mnt/us/LARK

exit 0
