#!/bin/sh

set -e

rm -rf /mnt/us/extensions/kterm

exit 0