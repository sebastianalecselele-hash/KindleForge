#!/bin/sh

set -e

echo "NOT COMPLETED"

rm -rf /mnt/us/documents/KUAL.jar
rm -f /mnt/us/documents/KUAL.sh

exit 0