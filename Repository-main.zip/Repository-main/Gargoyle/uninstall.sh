set -e

rm -rf /mnt/us/extensions/gargoyle

exit 0