#!/bin/sh

set -e

curl -fSL --progress-bar https://justrals.github.io/KindleFetch/install.sh | sh 

# Finish
exit 0