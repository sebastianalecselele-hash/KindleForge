#!/bin/sh

set -e

rm -rf /mnt/us/extensions/kindlefetch

exit 0