#!/bin/sh

set -e

rm -rf /mnt/us/extensions/JarLauncher

exit 0