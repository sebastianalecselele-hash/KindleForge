#!/bin/sh

set -e

rm -f /mnt/us/documents/KindleCraft.sh
rm -f /mnt/us/documents/KindleCraft
rm -f /mnt/us/documents/world.bin

exit 0