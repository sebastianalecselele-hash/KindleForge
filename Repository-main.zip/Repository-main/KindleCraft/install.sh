#!/bin/sh

set -e

curl -fSL --progress-bar -o /mnt/us/documents/KindleCraft.sh https://raw.githubusercontent.com/gingrspacecadet/bareiron/refs/heads/main/KindleCraft.sh
curl -fSL --progress-bar -o /mnt/us/documents/KindleCraft https://raw.githubusercontent.com/gingrspacecadet/bareiron/refs/heads/main/cross

exit 0