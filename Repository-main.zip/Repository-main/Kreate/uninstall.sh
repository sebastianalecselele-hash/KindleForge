#!/bin/sh

set -e

rm -rf /mnt/us/documents/kreate

# Finish
exit 0