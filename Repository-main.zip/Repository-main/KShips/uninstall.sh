#!/bin/sh

set -e

rm -rf /mnt/us/documents/KShips/
rm -rf /var/local/mesquite/KShips/
rm -f /mnt/us/documents/KShips.sh

exit 0